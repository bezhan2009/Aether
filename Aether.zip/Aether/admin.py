from django.contrib import admin

# Admin panel
